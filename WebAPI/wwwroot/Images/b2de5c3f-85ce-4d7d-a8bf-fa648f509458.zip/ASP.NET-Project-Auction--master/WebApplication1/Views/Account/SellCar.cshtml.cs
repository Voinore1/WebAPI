using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.Account
{
    public class SellCarModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
